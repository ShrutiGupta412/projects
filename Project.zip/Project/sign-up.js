function validate(){ 
    var e=document.form.email.value;
    var firstpassword=document.form.password.value;  
    var secondpassword=document.form.cpassword.value;  
    if(e=="" || firstpassword=="" || secondpassword=="")
    {
        alert("fill the required fields");
    }
    else if(firstpassword!=secondpassword)
    {  
alert("password must be same!");  
  }  
    else  {  
        window.location.href = "sign-in.html";

    alert("Registered Successfully");   
    } 
    }  