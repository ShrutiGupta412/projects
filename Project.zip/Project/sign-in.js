function validate()
{
  var email=document.form.email.value;
  var pass=document.form.password.value;
  if(email=="" || pass=="")
  {
     alert("Provide the required credentials");
     
  }
  else{
    alert("redirecting to website .Click ok")
  }
}
