function validate()
{
  var aid=document.form.aid.value;
  var pass=document.form.apass.value;
  if(aid=="" || apass=="")
  {
     alert("Provide the required credentials");
     
  }
  else{
    alert("redirecting to website .Click ok")
  }
}
